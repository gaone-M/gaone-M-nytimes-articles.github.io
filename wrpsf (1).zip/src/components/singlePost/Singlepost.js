import React, { Component } from "react";

export default class SinglePost extends Component {
  render() {
    return <div>Single big post</div>;
  }
}
